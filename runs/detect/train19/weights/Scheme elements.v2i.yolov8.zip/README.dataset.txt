# Scheme elements > 2024-10-16 9:12pm
https://universe.roboflow.com/estonia-bip/scheme-elements

Provided by a Roboflow user
License: CC BY 4.0

